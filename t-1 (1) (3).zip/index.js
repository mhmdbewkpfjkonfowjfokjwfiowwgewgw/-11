const {
    Client,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputStyle,
    TextInputBuilder, 
    MessageEmbed, 
    MessageButton, 
    MessageActionRow, 
    StringSelectMenuBuilder, 
    AttachmentBuilder, 
    BitField,
    PermissionOverwriteFlags,
    SlashCommandBuilder, 
    SelectMenuBuilder, 
    ChannelType, 
    StringSelectMenuInteraction,
    REST,
    Routes
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const { PermissionsBitField } = require('discord.js');
const Discord = require('discord.js');
const client = new Client({ intents: ['Guilds', 'MessageContent', 'GuildMessages','GuildMembers'] });
const t = 'tokenbot';
client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});
const room = "1256179926646657126";//ايدي روم
client.on('messageCreate', async message => {
    if (message.content === '#انشاء-هوية') {
        const embed = new EmbedBuilder()
            .setDescription('لانشاء هويتك برجاء ضغط على زر وعبي الاستبيان كمال .')
            .setColor(0x000000)
            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('fillForm')
                    .setLabel('انشاء هوية')
                    .setStyle(ButtonStyle.Primary),
            );

        await message.channel.send({ embeds: [embed], components: [row] });
    }
});

client.on('interactionCreate', async interaction => {
    if (interaction.isButton() && interaction.customId === 'fillForm') {
        const modal = new ModalBuilder()
            .setCustomId('identityForm')
            .setTitle('انشاء هوية وطنية')
            .addComponents(
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('name')
                        .setLabel('اسم الكريم؟')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true),
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('age')
                        .setLabel('عمرك؟')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true),
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('birthdate')
                        .setLabel('تاريخ ميلادك؟')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true),
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('birthplace')
                        .setLabel('مكان الميلاد؟')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true),
                ),
                new ActionRowBuilder().addComponents(
                    new TextInputBuilder()
                        .setCustomId('idNumber')
                        .setLabel('رقم هويتك؟')
                        .setStyle(TextInputStyle.Short)
                        .setRequired(true),
                ),
            );

        await interaction.showModal(modal);
    } else if (interaction.isModalSubmit() && interaction.customId === 'identityForm') {
        const name = interaction.fields.getTextInputValue('name');
        const age = interaction.fields.getTextInputValue('age');
        const birthdate = interaction.fields.getTextInputValue('birthdate');
        const birthplace = interaction.fields.getTextInputValue('birthplace');
        const idNumber = interaction.fields.getTextInputValue('idNumber');

        const userData = { name, age, birthdate, birthplace, idNumber };

        const identityEmbed = new EmbedBuilder()
            .setTitle('انشاء هوية وطنية')
            .setDescription(`- انشاء هوية من ${interaction.user}\n\n- الاسم: ${name}\n\n- العمر: ${age}\n\n- تاريخ الميلاد: ${birthdate}\n\n- مكان الميلاد: ${birthplace}\n\n- رقم هوية: ${idNumber}`)
            .setColor(0x000000)
            .setThumbnail(interaction.user.displayAvatarURL())
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
            .setTimestamp();

        const logChannel = client.channels.cache.get(room);
        if (logChannel) {
            await logChannel.send({ embeds: [identityEmbed] });
        }

        await interaction.reply({ content: 'تم انشاء هويتك بنجاح! لمعرفة هويتك اكتب: #هويتي', ephemeral: true });

        const filePath = path.join(__dirname, 'userData.json');
        let allUserData = {};
        if (fs.existsSync(filePath)) {
            allUserData = JSON.parse(fs.readFileSync(filePath));
        }

        allUserData[interaction.user.id] = userData;
        fs.writeFileSync(filePath, JSON.stringify(allUserData, null, 2));
    }
});

client.on('messageCreate', async message => {
    if (message.content === '#هويتي') {
        const filePath = path.join(__dirname, 'userData.json');
        if (!fs.existsSync(filePath)) {
            await message.channel.send('لم يتم العثور على أي بيانات هوية.');
            return;
        }

        const allUserData = JSON.parse(fs.readFileSync(filePath));
        const userData = allUserData[message.author.id];

        if (!userData) {
            await message.channel.send('لم يتم العثور على أي بيانات هوية خاصة بك.');
            return;
        }

        const identityEmbed = new EmbedBuilder()
            .setTitle('هويتك وطنية')
            .setDescription(`- اسمك: ${userData.name}\n\n- عمرك: ${userData.age}\n\n- تاريخ ميلادك: ${userData.birthdate}\n\n- مكان ميلادك: ${userData.birthplace}\n\n- رقم هويتك: ${userData.idNumber}`)
            .setColor(0x000000)
            .setThumbnail(message.author.displayAvatarURL())
            .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
            .setTimestamp();
await message.reply({ embeds: [identityEmbed] });
        await message.author.send({ embeds: [identityEmbed] });
    }
});
client.login("MTI1NjA1OTgwNDg5MjM5NzU3OA.Gnlj-F.i59XzXntTUwVhd76nohtrFMCWfXyPtIhd171Fo"); 